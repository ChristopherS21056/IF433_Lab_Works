package oop_122030_ChristopherSunyoto_Week11.TUGAS

fun main() {
    val homeDevices = mutableListOf<SmartDevice>()
    homeDevices.add(
        SmartDevice("Philips WiZ Living Room", "Lighting").apply {
            isOnline = true
            powerLoad = 12
        }
    )
    SmartDevice("Ezviz Outdoor", "Camera").apply {
        isOnline = true
        powerLoad = 5
    }.also {
        println("(LOG) Kamera terhubung")
        homeDevices.add(it)
    }
    val acUnit = run {
        SmartDevice("Daikin Inverter (Kabel 3x2.5)", "HVAC", false, 800)
    }
    homeDevices.add(acUnit)
    homeDevices.add(SmartDevice("Picolo's Auto Feeder", "Pet Care", true, 10))

    val searchResult = homeDevices.find { it.category == "Camera" }
    searchResult?.let {
        println(it.diagnose())
    }

    with(homeDevices) {
        println("Total Perangkat: ${this.size}")
    }

    val totalPower = homeDevices.run { sumOf { it.powerLoad } }
    println("Total Penggunaan Daya: $totalPower Watt")

    println("\n=== DASHBOARD DIAGNOSTIC ===")
    homeDevices.forEach { println(it.diagnose()) }
}